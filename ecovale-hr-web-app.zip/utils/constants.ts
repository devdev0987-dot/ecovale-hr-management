
import { Department } from '../types';

export const DEPARTMENTS: Department[] = ['IT', 'HR', 'Finance', 'Sales', 'Marketing'];

export const WORK_LOCATIONS = ['HQ', 'Branch-A', 'Branch-B', 'Remote'];

export const GENDERS = ['Male', 'Female', 'Other'];

export const EMPLOYEE_TYPES = ['full-time', 'part-time'];

export const PAYMENT_MODES = ['Bank', 'Cash', 'Cheque'];

export const STATUSES = ['active', 'inactive'];
