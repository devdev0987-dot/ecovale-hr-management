
export const formatDate = (dateString: string) => {
  if (!dateString) return '';
  try {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  } catch (error) {
    return dateString;
  }
};

export const generateUniqueId = () => {
  return `id_${new Date().getTime()}_${Math.random().toString(36).substr(2, 9)}`;
};

export const generateEmployeeId = (count: number) => {
  const number = (count + 1).toString().padStart(3, '0');
  return `EMP${number}`;
};

export const validateEmail = (email: string) => {
  const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(String(email).toLowerCase());
};

export const calculateSalary = (basic: number, hra: number, da: number, specialAllowance: number, includePF: boolean, includeESI: boolean, pt: number, tds: number) => {
    const gross = basic + hra + da + specialAllowance;
    const pfDeduction = includePF ? basic * 0.12 : 0;
    const esiDeduction = (includeESI && gross < 21000) ? gross * 0.0075 : 0;
    const net = gross - pfDeduction - esiDeduction - pt - tds;
    return { gross, pfDeduction, esiDeduction, net };
};

export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
  });
};
