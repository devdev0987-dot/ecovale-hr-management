
export type Department = 'IT' | 'HR' | 'Finance' | 'Sales' | 'Marketing';

export type Designation = {
  id: string;
  title: string;
  department: Department;
  description: string;
  reportingTo?: string;
  level: number;
};

export interface BankDetails {
  bankName: string;
  accountHolder: string;
  accountNumber: string;
  ifscCode: string;
  branch: string;
}

export interface SalaryInfo {
  basic: number;
  hra: number;
  da: number;
  specialAllowance: number;
  otherAllowances: { name: string; amount: number }[];
  gross: number;
  includePF: boolean;
  includeESI: boolean;
  pfDeduction: number;
  esiDeduction: number;
  professionalTax: number;
  tds: number;
  net: number;
  paymentMode: 'Bank' | 'Cash' | 'Cheque';
  bankDetails?: BankDetails;
}

export interface Document {
  type: string;
  fileName: string;
  data: string; // base64
  uploadDate: string;
}

export interface CareerHistoryItem {
  type: 'promotion' | 'increment' | 'demotion';
  date: string;
  details: any;
}

export interface Employee {
  id: string;
  personalInfo: {
    firstName: string;
    middleName?: string;
    lastName: string;
    dob: string;
    gender: 'Male' | 'Female' | 'Other';
    photo?: string; // base64
    contactNumber: string;
    alternateContact?: string;
    personalEmail: string;
    permanentAddress: string;
    currentAddress: string;
  };
  employmentDetails: {
    type: 'full-time' | 'part-time';
    department: Department;
    designation: string;
    reportingManager?: string;
    joinDate: string;
    officialEmail: string;
    workLocation: 'HQ' | 'Branch-A' | 'Branch-B' | 'Remote';
    probationPeriod: number;
  };
  salaryInfo: SalaryInfo;
  documents: Document[];
  careerHistory: CareerHistoryItem[];
  status: 'active' | 'inactive';
  createdAt: string;
  updatedAt: string;
}

export type Page = 
  | 'dashboard' 
  | 'employees' 
  | 'new-employee' 
  | 'designations' 
  | 'letters' 
  | 'payroll' 
  | 'calculator' 
  | 'career' 
  | 'settings';
