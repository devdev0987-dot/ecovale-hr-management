
import React, { useState } from 'react';

const CareerPage: React.FC = () => {
    const [activeTab, setActiveTab] = useState('promotions');

    const renderContent = () => {
        switch (activeTab) {
            case 'promotions':
                return <div className="p-4"><h3 className="text-xl font-semibold">Promotions History</h3><p className="text-gray-600 mt-2">Promotion records will be displayed here.</p></div>;
            case 'increments':
                return <div className="p-4"><h3 className="text-xl font-semibold">Increments History</h3><p className="text-gray-600 mt-2">Salary increment records will be displayed here.</p></div>;
            case 'demotions':
                return <div className="p-4"><h3 className="text-xl font-semibold">Demotions History</h3><p className="text-gray-600 mt-2">Demotion records will be displayed here.</p></div>;
            default:
                return null;
        }
    };
    
    const TabButton = ({ tabName, label }) => (
        <button
            onClick={() => setActiveTab(tabName)}
            className={`px-4 py-2 text-sm font-medium rounded-md ${activeTab === tabName ? 'bg-green-600 text-white' : 'text-gray-600 hover:bg-gray-100'}`}
        >
            {label}
        </button>
    );

    return (
        <div>
            <h2 className="text-2xl font-semibold text-gray-800 mb-6">Career Management</h2>
            <div className="bg-white rounded-lg shadow-md">
                <div className="p-4 border-b">
                    <div className="flex space-x-2">
                        <TabButton tabName="promotions" label="Promotions" />
                        <TabButton tabName="increments" label="Increments" />
                        <TabButton tabName="demotions" label="Demotions" />
                    </div>
                </div>
                <div>{renderContent()}</div>
            </div>
        </div>
    );
};

export default CareerPage;
