
import React, { useReducer, useEffect, useState } from 'react';
import { saveEmployee, getDesignations, getEmployees } from '../services/storageService';
import { Employee, Designation } from '../types';
import { DEPARTMENTS, WORK_LOCATIONS, GENDERS, PAYMENT_MODES } from '../utils/constants';
import Button from '../components/ui/Button';
import { useAppContext } from '../contexts/AppContext';
import { calculateSalary, fileToBase64, validateEmail } from '../utils/helpers';
import Input from '../components/ui/Input';


const initialFormData: Omit<Employee, 'id' | 'createdAt' | 'updatedAt'> = {
    personalInfo: { firstName: '', lastName: '', dob: '', gender: 'Male', contactNumber: '', personalEmail: '', permanentAddress: '', currentAddress: '' },
    employmentDetails: { type: 'full-time', department: 'IT', designation: '', joinDate: '', officialEmail: '', workLocation: 'HQ', probationPeriod: 6 },
    salaryInfo: { basic: 0, hra: 0, da: 0, specialAllowance: 0, otherAllowances: [], gross: 0, includePF: true, includeESI: false, pfDeduction: 0, esiDeduction: 0, professionalTax: 200, tds: 0, net: 0, paymentMode: 'Bank' },
    documents: [],
    careerHistory: [],
    status: 'active'
};

function formReducer(state, action) {
    switch (action.type) {
        case 'UPDATE_FIELD':
            const { section, field, value } = action.payload;
            const newState = { ...state };
            newState[section][field] = value;
            
            // Auto-generate official email
            if (section === 'personalInfo' && (field === 'firstName' || field === 'lastName')) {
                const firstName = (field === 'firstName' ? value : state.personalInfo.firstName).toLowerCase();
                const lastName = (field === 'lastName' ? value : state.personalInfo.lastName).toLowerCase();
                if(firstName && lastName) {
                    newState.employmentDetails.officialEmail = `${firstName}.${lastName}@ecovale.com`;
                }
            }
            
            return newState;
        case 'UPDATE_SALARY':
             return { ...state, salaryInfo: { ...state.salaryInfo, ...action.payload } };
        case 'SET_PHOTO':
            return { ...state, personalInfo: { ...state.personalInfo, photo: action.payload } };
        case 'RESET':
            return initialFormData;
        default:
            return state;
    }
}

const NewEmployeePage: React.FC = () => {
    const { showToast, setActivePage } = useAppContext();
    const [state, dispatch] = useReducer(formReducer, initialFormData);
    const [designations, setDesignations] = useState<Designation[]>([]);
    const [employees, setEmployees] = useState<Employee[]>([]);
    const [errors, setErrors] = useState<any>({});
    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [desigs, emps] = await Promise.all([getDesignations(), getEmployees()]);
                setDesignations(desigs);
                setEmployees(emps);
            } catch (error) {
                showToast('Failed to load initial form data', 'error');
            }
        };
        fetchData();
    }, [showToast]);

    useEffect(() => {
        const { basic, hra, da, specialAllowance, includePF, includeESI, professionalTax, tds } = state.salaryInfo;
        const { gross, pfDeduction, esiDeduction, net } = calculateSalary(
            Number(basic) || 0, Number(hra) || 0, Number(da) || 0, Number(specialAllowance) || 0,
            includePF, includeESI, Number(professionalTax) || 0, Number(tds) || 0
        );
        dispatch({ type: 'UPDATE_SALARY', payload: { gross, pfDeduction, esiDeduction, net } });
    }, [state.salaryInfo.basic, state.salaryInfo.hra, state.salaryInfo.da, state.salaryInfo.specialAllowance, state.salaryInfo.includePF, state.salaryInfo.includeESI, state.salaryInfo.professionalTax, state.salaryInfo.tds]);


    const handleChange = (section: string, field: string, value: any) => {
        dispatch({ type: 'UPDATE_FIELD', payload: { section, field, value } });
    };

    const handlePhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            try {
                const base64 = await fileToBase64(e.target.files[0]);
                dispatch({ type: 'SET_PHOTO', payload: base64 });
            } catch (error) {
                showToast('Failed to upload photo', 'error');
            }
        }
    };

    const validateForm = () => {
        const newErrors: any = {};
        // Add more validations as per spec
        if (!state.personalInfo.firstName) newErrors.firstName = 'First name is required.';
        if (!state.personalInfo.lastName) newErrors.lastName = 'Last name is required.';
        if (!validateEmail(state.personalInfo.personalEmail)) newErrors.personalEmail = 'Invalid email format.';
        if (state.personalInfo.contactNumber.length !== 10) newErrors.contactNumber = 'Contact number must be 10 digits.';
        if (!state.employmentDetails.designation) newErrors.designation = 'Designation is required.';
        if (state.salaryInfo.basic <= 0) newErrors.basic = 'Basic salary must be greater than 0.';
        
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!validateForm()) {
            showToast('Please fix the errors before submitting.', 'error');
            return;
        }
        setIsSubmitting(true);
        try {
            await saveEmployee(state);
            showToast('Employee added successfully!', 'success');
            dispatch({ type: 'RESET' });
            setActivePage('employees');
        } catch (error) {
            showToast('Failed to save employee.', 'error');
        } finally {
            setIsSubmitting(false);
        }
    };

    const renderSection = (title: string, children: React.ReactNode) => (
        <div className="bg-white p-6 rounded-lg shadow-md mb-6">
            <h3 className="text-xl font-semibold text-gray-800 border-b pb-3 mb-4">{title}</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {children}
            </div>
        </div>
    );

    return (
        <form onSubmit={handleSubmit} className="max-w-6xl mx-auto">
            <h2 className="text-2xl font-semibold text-gray-800 mb-6">Create New Employee</h2>
            
            {renderSection('Personal Information', <>
                <Input label="First Name*" id="firstName" value={state.personalInfo.firstName} onChange={e => handleChange('personalInfo', 'firstName', e.target.value)} error={errors.firstName} />
                <Input label="Middle Name" id="middleName" value={state.personalInfo.middleName} onChange={e => handleChange('personalInfo', 'middleName', e.target.value)} />
                <Input label="Last Name*" id="lastName" value={state.personalInfo.lastName} onChange={e => handleChange('personalInfo', 'lastName', e.target.value)} error={errors.lastName} />
                <Input label="Date of Birth*" id="dob" type="date" value={state.personalInfo.dob} onChange={e => handleChange('personalInfo', 'dob', e.target.value)} error={errors.dob} />
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Gender*</label>
                    <select className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500" value={state.personalInfo.gender} onChange={e => handleChange('personalInfo', 'gender', e.target.value)}>
                        {GENDERS.map(g => <option key={g} value={g}>{g}</option>)}
                    </select>
                </div>
                 <Input label="Contact Number*" id="contactNumber" type="tel" value={state.personalInfo.contactNumber} onChange={e => handleChange('personalInfo', 'contactNumber', e.target.value)} error={errors.contactNumber} />
                 <Input label="Personal Email*" id="personalEmail" type="email" value={state.personalInfo.personalEmail} onChange={e => handleChange('personalInfo', 'personalEmail', e.target.value)} error={errors.personalEmail} />
                 <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Permanent Address*</label>
                    <textarea className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500" value={state.personalInfo.permanentAddress} onChange={e => handleChange('personalInfo', 'permanentAddress', e.target.value)} />
                </div>
                <div className="flex items-center">
                    <img src={state.personalInfo.photo || 'https://picsum.photos/100'} alt="Profile" className="w-16 h-16 rounded-full mr-4" />
                    <Input label="Profile Photo" id="photo" type="file" onChange={handlePhotoChange} />
                </div>
            </>)}

            {renderSection('Employment Details', <>
                 <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Employee Type*</label>
                     <select className="mt-1 block w-full rounded-md border-gray-300 shadow-sm" value={state.employmentDetails.type} onChange={e => handleChange('employmentDetails', 'type', e.target.value)}>
                         <option value="full-time">Full-Time</option>
                         <option value="part-time">Part-Time</option>
                     </select>
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Department*</label>
                     <select className="mt-1 block w-full rounded-md border-gray-300 shadow-sm" value={state.employmentDetails.department} onChange={e => handleChange('employmentDetails', 'department', e.target.value)}>
                         {DEPARTMENTS.map(d => <option key={d} value={d}>{d}</option>)}
                     </select>
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Designation*</label>
                    {/* Fix: Replaced invalid 'error' prop on select with conditional styling and a separate error message element. */}
                     <select 
                        className={`mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500 ${errors.designation ? 'border-red-500' : ''}`}
                        value={state.employmentDetails.designation} 
                        onChange={e => handleChange('employmentDetails', 'designation', e.target.value)}
                     >
                        <option value="">Select Designation</option>
                        {designations.filter(d => d.department === state.employmentDetails.department).map(d => <option key={d.id} value={d.title}>{d.title}</option>)}
                     </select>
                     {errors.designation && <p className="mt-1 text-xs text-red-600">{errors.designation}</p>}
                </div>
                <Input label="Official Email" id="officialEmail" value={state.employmentDetails.officialEmail} readOnly className="bg-gray-100" />
                <Input label="Join Date*" id="joinDate" type="date" value={state.employmentDetails.joinDate} onChange={e => handleChange('employmentDetails', 'joinDate', e.target.value)} />
                <Input label="Probation (months)" id="probation" type="number" value={state.employmentDetails.probationPeriod} onChange={e => handleChange('employmentDetails', 'probationPeriod', e.target.value)} />
            </>)}

            {renderSection('Salary & Compensation', <>
                <Input label="Basic Salary*" id="basic" type="number" value={state.salaryInfo.basic} onChange={e => handleChange('salaryInfo', 'basic', e.target.value)} error={errors.basic} />
                <Input label="HRA" id="hra" type="number" value={state.salaryInfo.hra} onChange={e => handleChange('salaryInfo', 'hra', e.target.value)} />
                <Input label="DA" id="da" type="number" value={state.salaryInfo.da} onChange={e => handleChange('salaryInfo', 'da', e.target.value)} />
                <Input label="Special Allowance" id="specialAllowance" type="number" value={state.salaryInfo.specialAllowance} onChange={e => handleChange('salaryInfo', 'specialAllowance', e.target.value)} />
                <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-500">Gross Salary</p>
                    <p className="text-xl font-bold text-gray-800">₹ {state.salaryInfo.gross.toFixed(2)}</p>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-500">Net Salary</p>
                    <p className="text-xl font-bold text-green-600">₹ {state.salaryInfo.net.toFixed(2)}</p>
                </div>
                 <div className="flex items-center space-x-4">
                    <label className="flex items-center"><input type="checkbox" checked={state.salaryInfo.includePF} onChange={e => handleChange('salaryInfo', 'includePF', e.target.checked)} className="h-4 w-4 rounded" /> <span className="ml-2">Include PF</span></label>
                    <label className="flex items-center"><input type="checkbox" checked={state.salaryInfo.includeESI} onChange={e => handleChange('salaryInfo', 'includeESI', e.target.checked)} className="h-4 w-4 rounded" /> <span className="ml-2">Include ESI</span></label>
                </div>
                 <Input label="Professional Tax" id="pt" type="number" value={state.salaryInfo.professionalTax} onChange={e => handleChange('salaryInfo', 'professionalTax', e.target.value)} />
                 <Input label="TDS" id="tds" type="number" value={state.salaryInfo.tds} onChange={e => handleChange('salaryInfo', 'tds', e.target.value)} />
            </>)}


            <div className="sticky bottom-0 bg-white p-4 border-t shadow-inner flex justify-end space-x-4">
                <Button type="button" variant="secondary" onClick={() => setActivePage('employees')}>Cancel</Button>
                <Button type="submit" isLoading={isSubmitting}>Submit</Button>
            </div>
        </form>
    );
};

export default NewEmployeePage;
