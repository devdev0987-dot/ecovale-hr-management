
import React, { useState, useEffect } from 'react';
import { getEmployees } from '../services/storageService';
import Button from '../components/ui/Button';

const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const years = [new Date().getFullYear(), new Date().getFullYear() - 1];

const PayrollPage: React.FC = () => {
    const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
    const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
    const [payrollData, setPayrollData] = useState([]);
    const [isProcessing, setIsProcessing] = useState(false);
    
    // Summary states
    const [totalGross, setTotalGross] = useState(0);
    const [totalDeductions, setTotalDeductions] = useState(0);
    const [totalNet, setTotalNet] = useState(0);
    const [totalEmployees, setTotalEmployees] = useState(0);

    const processPayroll = async () => {
        setIsProcessing(true);
        try {
            const employees = await getEmployees();
            const payroll = employees.map(emp => {
                const deductions = emp.salaryInfo.pfDeduction + emp.salaryInfo.esiDeduction + emp.salaryInfo.professionalTax + emp.salaryInfo.tds;
                return {
                    employeeId: emp.id,
                    name: `${emp.personalInfo.firstName} ${emp.personalInfo.lastName}`,
                    designation: emp.employmentDetails.designation,
                    gross: emp.salaryInfo.gross,
                    deductions,
                    net: emp.salaryInfo.net,
                    status: 'Processed'
                };
            });
            setPayrollData(payroll);
            // Calculate summaries
            setTotalEmployees(payroll.length);
            setTotalGross(payroll.reduce((acc, p) => acc + p.gross, 0));
            setTotalDeductions(payroll.reduce((acc, p) => acc + p.deductions, 0));
            setTotalNet(payroll.reduce((acc, p) => acc + p.net, 0));
        } catch (error) {
            console.error("Payroll processing failed:", error);
        } finally {
            setIsProcessing(false);
        }
    };

    return (
        <div>
            <h2 className="text-2xl font-semibold text-gray-800 mb-6">Payroll Management</h2>
            <div className="bg-white p-6 rounded-lg shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-4">
                    <select value={selectedMonth} onChange={e => setSelectedMonth(Number(e.target.value))} className="p-2 border rounded-md">
                        {months.map((m, i) => <option key={i} value={i}>{m}</option>)}
                    </select>
                    <select value={selectedYear} onChange={e => setSelectedYear(Number(e.target.value))} className="p-2 border rounded-md">
                        {years.map(y => <option key={y} value={y}>{y}</option>)}
                    </select>
                    <Button onClick={processPayroll} isLoading={isProcessing}>Process Payroll</Button>
                </div>
            </div>

            {payrollData.length > 0 && (
                <>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                    <div className="bg-white p-4 rounded-lg shadow-md"><p className="text-sm text-gray-500">Total Employees</p><p className="text-2xl font-bold">{totalEmployees}</p></div>
                    <div className="bg-white p-4 rounded-lg shadow-md"><p className="text-sm text-gray-500">Total Gross</p><p className="text-2xl font-bold">₹{totalGross.toLocaleString()}</p></div>
                    <div className="bg-white p-4 rounded-lg shadow-md"><p className="text-sm text-gray-500">Total Deductions</p><p className="text-2xl font-bold">₹{totalDeductions.toLocaleString()}</p></div>
                    <div className="bg-white p-4 rounded-lg shadow-md"><p className="text-sm text-gray-500">Total Net Pay</p><p className="text-2xl font-bold">₹{totalNet.toLocaleString()}</p></div>
                </div>

                <div className="bg-white p-6 rounded-lg shadow-md overflow-x-auto">
                    <table className="w-full text-sm">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th className="px-6 py-3">ID</th>
                                <th className="px-6 py-3">Name</th>
                                <th className="px-6 py-3">Gross</th>
                                <th className="px-6 py-3">Deductions</th>
                                <th className="px-6 py-3">Net Pay</th>
                                <th className="px-6 py-3">Status</th>
                                <th className="px-6 py-3">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {payrollData.map(p => (
                                <tr key={p.employeeId} className="border-b hover:bg-gray-50">
                                    <td className="px-6 py-4">{p.employeeId}</td>
                                    <td className="px-6 py-4 font-semibold">{p.name}</td>
                                    <td className="px-6 py-4">₹{p.gross.toLocaleString()}</td>
                                    <td className="px-6 py-4 text-red-600">₹{p.deductions.toLocaleString()}</td>
                                    <td className="px-6 py-4 font-bold text-green-600">₹{p.net.toLocaleString()}</td>
                                    <td className="px-6 py-4"><span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">{p.status}</span></td>
                                    <td className="px-6 py-4"><Button variant="secondary" size="sm">View Slip</Button></td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                </>
            )}
        </div>
    );
};

export default PayrollPage;
