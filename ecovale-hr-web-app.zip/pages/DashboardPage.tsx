
import React, { useEffect, useState } from 'react';
import { Users, UserCheck, UserX, AlertTriangle, UserPlus, FileText, Banknote, Calculator } from 'lucide-react';
import { getEmployees } from '../services/storageService';
import { useAppContext } from '../contexts/AppContext';

const MetricCard = ({ icon, title, value, bgColor }) => (
  <div className="bg-white p-6 rounded-lg shadow-md flex items-center space-x-4">
    <div className={`p-3 rounded-full ${bgColor}`}>
      {icon}
    </div>
    <div>
      <p className="text-sm text-gray-600">{title}</p>
      <p className="text-3xl font-bold text-gray-800">{value}</p>
    </div>
  </div>
);

const QuickActionButton = ({ icon, label, page }) => {
  const { setActivePage } = useAppContext();
  return (
    <button onClick={() => setActivePage(page)} className="bg-white p-6 rounded-lg shadow-md flex flex-col items-center justify-center space-y-2 hover:bg-gray-50 transition-colors">
      {icon}
      <span className="text-gray-700 font-medium">{label}</span>
    </button>
  );
};


const DashboardPage: React.FC = () => {
  const [metrics, setMetrics] = useState({
    totalEmployees: 0,
    fullTime: 0,
    partTime: 0,
    pendingActions: 5 // Mock value
  });

  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const employees = await getEmployees();
        setMetrics(prev => ({
          ...prev,
          totalEmployees: employees.length,
          fullTime: employees.filter(e => e.employmentDetails.type === 'full-time').length,
          partTime: employees.filter(e => e.employmentDetails.type === 'part-time').length,
        }));
      } catch (error) {
        console.error("Failed to fetch employees for metrics:", error);
      }
    };
    fetchMetrics();
  }, []);

  return (
    <div>
      <h2 className="text-2xl font-semibold text-gray-800 mb-6">Welcome, Admin!</h2>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <MetricCard icon={<Users className="text-blue-600"/>} title="Total Employees" value={metrics.totalEmployees} bgColor="bg-blue-100" />
        <MetricCard icon={<UserCheck className="text-green-600"/>} title="Full-Time" value={metrics.fullTime} bgColor="bg-green-100" />
        <MetricCard icon={<UserX className="text-orange-600"/>} title="Part-Time" value={metrics.partTime} bgColor="bg-orange-100" />
        <MetricCard icon={<AlertTriangle className="text-red-600"/>} title="Pending Actions" value={metrics.pendingActions} bgColor="bg-red-100" />
      </div>

      {/* Quick Actions */}
      <div className="mb-8">
        <h3 className="text-xl font-semibold text-gray-700 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <QuickActionButton icon={<UserPlus size={32} className="text-green-600" />} label="Add Employee" page="new-employee" />
          <QuickActionButton icon={<FileText size={32} className="text-indigo-600" />} label="Generate Letter" page="letters" />
          <QuickActionButton icon={<Banknote size={32} className="text-yellow-600" />} label="Process Payroll" page="payroll" />
          <QuickActionButton icon={<Calculator size={32} className="text-purple-600" />} label="Calculate ESI/PF" page="calculator" />
        </div>
      </div>

      {/* Charts & Activities */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-semibold text-gray-700 mb-4">Department-wise Distribution</h3>
          <div className="h-64 bg-gray-200 rounded-md flex items-center justify-center">
            <p className="text-gray-500">Bar Chart Placeholder</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-semibold text-gray-700 mb-4">Recent Activities</h3>
          <ul className="space-y-4">
            <li className="text-sm text-gray-600">New employee <span className="font-medium text-gray-800">John Doe</span> added.</li>
            <li className="text-sm text-gray-600">Payroll for <span className="font-medium text-gray-800">July 2024</span> processed.</li>
            <li className="text-sm text-gray-600">Offer letter generated for <span className="font-medium text-gray-800">Jane Smith</span>.</li>
            <li className="text-sm text-gray-600">Designation <span className="font-medium text-gray-800">"Lead Engineer"</span> created.</li>
            <li className="text-sm text-gray-600">Employee <span className="font-medium text-gray-800">Mike Ross</span> profile updated.</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
