
import React, { useState, useEffect } from 'react';
import { getEmployees } from '../services/storageService';
import { Employee } from '../types';
import Button from '../components/ui/Button';
import { formatDate } from '../utils/helpers';

const LetterPreview = ({ employee, joinDate, additionalTerms }) => {
    if (!employee) {
        return <div className="p-8 border rounded-lg bg-gray-50 text-center text-gray-500">Select an employee to see a preview.</div>;
    }

    return (
        <div className="p-8 border rounded-lg bg-white shadow-inner">
            <div className="border-b pb-4 mb-4">
                <h2 className="text-2xl font-bold text-gray-800">EcoVale Technologies Pvt. Ltd.</h2>
                <p className="text-sm text-gray-600">123 Business Park, Bangalore - 560001</p>
            </div>
            <div className="flex justify-between mb-6">
                <div>
                    <p>{employee.personalInfo.firstName} {employee.personalInfo.lastName}</p>
                    <p className="text-sm text-gray-600">{employee.personalInfo.permanentAddress}</p>
                </div>
                <p className="text-sm text-gray-600">Date: {formatDate(new Date().toISOString())}</p>
            </div>
            <h3 className="font-bold mb-4">Subject: Offer of Employment - {employee.employmentDetails.designation}</h3>
            <div className="space-y-4 text-sm text-gray-700">
                <p>Dear {employee.personalInfo.firstName},</p>
                <p>We are pleased to offer you the position of {employee.employmentDetails.designation} at EcoVale Technologies. We were impressed with your background and believe you will be a valuable asset to our team.</p>
                <div className="p-4 bg-gray-50 rounded-md">
                    <h4 className="font-semibold mb-2">Compensation Details:</h4>
                    <ul className="list-disc list-inside">
                        <li>Basic Salary: ₹{employee.salaryInfo.basic.toLocaleString()}</li>
                        <li>HRA: ₹{employee.salaryInfo.hra.toLocaleString()}</li>
                        <li className="font-bold">Gross Salary: ₹{employee.salaryInfo.gross.toLocaleString()} per month</li>
                        <li className="font-bold">Net Salary (Approx): ₹{employee.salaryInfo.net.toLocaleString()} per month</li>
                    </ul>
                </div>
                <p>Your anticipated start date is {formatDate(joinDate)}. This offer is contingent upon successful completion of background checks.</p>
                {additionalTerms && <div className="p-4 border-t mt-4"><p className="font-semibold">Additional Terms:</p><p className="whitespace-pre-wrap">{additionalTerms}</p></div>}
                <p>Sincerely,</p>
                <p className="font-bold">HR Department</p>
                <p>EcoVale Technologies</p>
            </div>
        </div>
    );
};

const LettersPage: React.FC = () => {
    const [employees, setEmployees] = useState<Employee[]>([]);
    const [selectedEmployeeId, setSelectedEmployeeId] = useState<string>('');
    const [joinDate, setJoinDate] = useState(new Date().toISOString().split('T')[0]);
    const [additionalTerms, setAdditionalTerms] = useState('');

    useEffect(() => {
        getEmployees().then(setEmployees);
    }, []);

    const selectedEmployee = employees.find(e => e.id === selectedEmployeeId);

    return (
        <div>
            <h2 className="text-2xl font-semibold text-gray-800 mb-6">Letters & Documents</h2>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-1 bg-white p-6 rounded-lg shadow-md">
                    <h3 className="text-xl font-semibold mb-4">Offer Letter Generator</h3>
                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Select Employee*</label>
                            <select
                                value={selectedEmployeeId}
                                onChange={(e) => setSelectedEmployeeId(e.target.value)}
                                className="w-full p-2 border rounded-md"
                            >
                                <option value="">-- Select an Employee --</option>
                                {employees.map(e => (
                                    <option key={e.id} value={e.id}>
                                        {e.personalInfo.firstName} {e.personalInfo.lastName} ({e.id})
                                    </option>
                                ))}
                            </select>
                        </div>
                        <div>
                           <label className="block text-sm font-medium text-gray-700 mb-1">Join Date*</label>
                           <input type="date" value={joinDate} onChange={e => setJoinDate(e.target.value)} className="w-full p-2 border rounded-md" />
                        </div>
                         <div>
                           <label className="block text-sm font-medium text-gray-700 mb-1">Additional Terms</label>
                           <textarea value={additionalTerms} onChange={e => setAdditionalTerms(e.target.value)} rows={5} className="w-full p-2 border rounded-md" />
                        </div>
                        <div className="flex space-x-2">
                             <Button>Download PDF</Button>
                             <Button variant="secondary">Save</Button>
                        </div>
                    </div>
                </div>
                <div className="lg:col-span-2">
                    <LetterPreview employee={selectedEmployee} joinDate={joinDate} additionalTerms={additionalTerms} />
                </div>
            </div>
        </div>
    );
};

export default LettersPage;
