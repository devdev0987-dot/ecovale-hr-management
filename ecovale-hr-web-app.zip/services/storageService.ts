
import { Employee, Designation, Department } from '../types';
import { generateEmployeeId, generateUniqueId } from '../utils/helpers';
import { DEPARTMENTS } from '../utils/constants';

// Fix: Define the custom storage API on the Window object for TypeScript
interface CustomStorage {
  get: (key: string) => Promise<{ value: string } | null>;
  set: (key: string, value: string) => Promise<void>;
}

declare global {
  interface Window {
    storage: CustomStorage;
  }
}

// --- MOCK window.storage API if not present ---
if (typeof window.storage === 'undefined') {
  console.warn('`window.storage` API not found. Mocking with in-memory storage.');
  const memoryStore: { [key: string]: string } = {};
  (window as any).storage = {
    get: async (key: string) => {
      const value = memoryStore[key];
      return value ? { value } : null;
    },
    set: async (key: string, value: string) => {
      memoryStore[key] = value;
    },
  };
}


// --- Seed Data ---
const seedDesignations: Designation[] = [
  { id: generateUniqueId(), title: 'Software Engineer', department: 'IT', level: 3, description: 'Develops software solutions.' },
  { id: generateUniqueId(), title: 'Senior Software Engineer', department: 'IT', level: 4, description: 'Leads development projects.' },
  { id: generateUniqueId(), title: 'HR Manager', department: 'HR', level: 5, description: 'Manages HR operations.' },
  { id: generateUniqueId(), title: 'Accountant', department: 'Finance', level: 3, description: 'Manages financial records.' },
  { id: generateUniqueId(), title: 'Sales Executive', department: 'Sales', level: 2, description: 'Drives sales and revenue.' }
];

const seedEmployees: Omit<Employee, 'id' | 'createdAt' | 'updatedAt'>[] = [
    {
        personalInfo: { firstName: "Alice", lastName: "Johnson", dob: "1992-05-20", gender: "Female", contactNumber: "9876543210", personalEmail: "alice.j@email.com", permanentAddress: "123 Maple St, Springfield", currentAddress: "123 Maple St, Springfield" },
        employmentDetails: { type: "full-time", department: "IT", designation: "Senior Software Engineer", joinDate: "2020-03-15", officialEmail: "alice.johnson@ecovale.com", workLocation: "HQ", probationPeriod: 6 },
        salaryInfo: { basic: 80000, hra: 32000, da: 8000, specialAllowance: 10000, otherAllowances: [], gross: 130000, includePF: true, includeESI: false, pfDeduction: 9600, esiDeduction: 0, professionalTax: 200, tds: 8000, net: 112200, paymentMode: "Bank" },
        documents: [], careerHistory: [], status: "active",
    },
    {
        personalInfo: { firstName: "Bob", lastName: "Smith", dob: "1995-11-30", gender: "Male", contactNumber: "8765432109", personalEmail: "bob.s@email.com", permanentAddress: "456 Oak Ave, Springfield", currentAddress: "456 Oak Ave, Springfield" },
        employmentDetails: { type: "part-time", department: "Finance", designation: "Accountant", joinDate: "2022-07-01", officialEmail: "bob.smith@ecovale.com", workLocation: "Remote", probationPeriod: 3 },
        salaryInfo: { basic: 20000, hra: 8000, da: 2000, specialAllowance: 1000, otherAllowances: [], gross: 31000, includePF: true, includeESI: false, pfDeduction: 2400, esiDeduction: 0, professionalTax: 200, tds: 1000, net: 27400, paymentMode: "Bank" },
        documents: [], careerHistory: [], status: "active",
    }
];

// --- Helper Functions ---
const getData = async <T,>(key: string, defaultValue: T): Promise<T> => {
  try {
    const result = await window.storage.get(key);
    if (result && result.value) {
      return JSON.parse(result.value) as T;
    }
    // If no data, seed it
    await window.storage.set(key, JSON.stringify(defaultValue));
    return defaultValue;
  } catch (error) {
    console.error(`Error getting data for key "${key}":`, error);
    return defaultValue;
  }
};

const setData = async <T,>(key: string, data: T): Promise<void> => {
  try {
    await window.storage.set(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Error setting data for key "${key}":`, error);
    throw new Error('Failed to save data.');
  }
};


// --- Departments API ---
export const getDepartments = async (): Promise<Department[]> => {
    return Promise.resolve(DEPARTMENTS);
};

// --- Designations API ---
export const getDesignations = async (): Promise<Designation[]> => {
  return getData<Designation[]>('designations', seedDesignations);
};

export const saveDesignation = async (designation: Omit<Designation, 'id'>): Promise<Designation> => {
  const designations = await getDesignations();
  const newDesignation: Designation = { ...designation, id: generateUniqueId() };
  const updatedDesignations = [...designations, newDesignation];
  await setData('designations', updatedDesignations);
  return newDesignation;
};

export const updateDesignation = async (updatedDesignation: Designation): Promise<Designation> => {
  const designations = await getDesignations();
  const index = designations.findIndex(d => d.id === updatedDesignation.id);
  if (index === -1) throw new Error('Designation not found');
  designations[index] = updatedDesignation;
  await setData('designations', designations);
  return updatedDesignation;
};

export const deleteDesignation = async (id: string): Promise<void> => {
  const designations = await getDesignations();
  const updatedDesignations = designations.filter(d => d.id !== id);
  await setData('designations', updatedDesignations);
};

// --- Employees API ---
const getInitialEmployees = (): Employee[] => {
    return seedEmployees.map((emp, index) => {
        const newEmp = {
            ...emp,
            id: generateEmployeeId(index),
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        // Auto-generate official email
        newEmp.employmentDetails.officialEmail = `${emp.personalInfo.firstName.toLowerCase()}.${emp.personalInfo.lastName.toLowerCase()}@ecovale.com`;
        return newEmp;
    });
};

export const getEmployees = async (): Promise<Employee[]> => {
  return getData<Employee[]>('employees', getInitialEmployees());
};

export const getEmployeeById = async (id: string): Promise<Employee | undefined> => {
    const employees = await getEmployees();
    return employees.find(e => e.id === id);
};

export const saveEmployee = async (employeeData: Omit<Employee, 'id' | 'createdAt' | 'updatedAt'>): Promise<Employee> => {
  const employees = await getEmployees();
  const newEmployee: Employee = {
    ...employeeData,
    id: generateEmployeeId(employees.length),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  const updatedEmployees = [...employees, newEmployee];
  await setData('employees', updatedEmployees);
  return newEmployee;
};

export const updateEmployee = async (updatedEmployee: Employee): Promise<Employee> => {
  const employees = await getEmployees();
  const index = employees.findIndex(e => e.id === updatedEmployee.id);
  if (index === -1) throw new Error('Employee not found');
  employees[index] = { ...updatedEmployee, updatedAt: new Date().toISOString() };
  await setData('employees', employees);
  return employees[index];
};

export const deleteEmployee = async (id: string): Promise<void> => {
  const employees = await getEmployees();
  const updatedEmployees = employees.filter(e => e.id !== id);
  await setData('employees', updatedEmployees);
};
